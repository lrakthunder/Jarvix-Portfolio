
import React, { useState } from 'react';

export const ContactModal: React.FC<{ isOpen: boolean; onClose: () => void; isDark: boolean }> = ({ isOpen, onClose, isDark }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 backdrop-blur-xl bg-black/60">
      <div className={`relative w-full max-w-lg p-8 border-2 ${isDark ? 'border-cyan-500/50 bg-gray-900' : 'border-blue-500/50 bg-white'} shadow-[0_0_50px_rgba(34,211,238,0.2)]`}>
        {/* Decor */}
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-cyan-400"></div>
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-cyan-400"></div>

        <button onClick={onClose} className="absolute top-4 right-4 text-cyan-500 hover:text-cyan-400">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <h2 className={`text-2xl font-orbitron font-bold mb-6 tracking-widest ${isDark ? 'text-cyan-300' : 'text-blue-800'}`}>ESTABLISH UPLINK</h2>
        
        <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert('Transmission Sent Securely'); onClose(); }}>
          <div>
            <label className={`block text-[10px] font-orbitron mb-1 ${isDark ? 'text-cyan-500' : 'text-blue-500'}`}>ORIGIN SIGNATURE</label>
            <input type="text" placeholder="Identity name" className={`w-full bg-transparent border-b ${isDark ? 'border-cyan-500/30 text-white' : 'border-blue-500/30 text-black'} py-2 outline-none focus:border-cyan-400 transition-colors font-mono`} required />
          </div>
          <div>
            <label className={`block text-[10px] font-orbitron mb-1 ${isDark ? 'text-cyan-500' : 'text-blue-500'}`}>COMMS CHANNEL</label>
            <input type="email" placeholder="email@address.net" className={`w-full bg-transparent border-b ${isDark ? 'border-cyan-500/30 text-white' : 'border-blue-500/30 text-black'} py-2 outline-none focus:border-cyan-400 transition-colors font-mono`} required />
          </div>
          <div>
            <label className={`block text-[10px] font-orbitron mb-1 ${isDark ? 'text-cyan-500' : 'text-blue-500'}`}>ENCRYPTED MESSAGE</label>
            <textarea rows={4} placeholder="Begin transmission..." className={`w-full bg-transparent border ${isDark ? 'border-cyan-500/30 text-white' : 'border-blue-500/30 text-black'} p-2 outline-none focus:border-cyan-400 transition-colors font-mono resize-none`} required></textarea>
          </div>
          
          <button type="submit" className={`w-full py-3 font-orbitron tracking-[0.3em] text-sm transition-all duration-300 
            ${isDark 
              ? 'bg-cyan-500/20 hover:bg-cyan-500/40 text-cyan-300 border border-cyan-400/50' 
              : 'bg-blue-600 text-white hover:bg-blue-700'}`}>
            INITIALIZE TRANSMISSION
          </button>
        </form>
      </div>
    </div>
  );
};
