
export type Section = 'overview' | 'projects' | 'experience' | 'background';

export interface Project {
  id: number;
  title: string;
  description: string;
  tags: string[];
  link: string;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'ARCHIVED';
}

export interface ExperienceItem {
  id: number;
  role: string;
  company: string;
  period: string;
  details: string[];
}

export interface Skill {
  name: string;
  level: number; // 0-100
  category: 'CORE' | 'FRONTEND' | 'BACKEND' | 'TOOLS';
}
