
import React from 'react';
import { Project, ExperienceItem, Skill } from './types';

export const USER_BIO = `
I am a Senior Full Stack Engineer specializing in creating high-performance web applications with immersive user interfaces. 
Expertise in React, TypeScript, and Generative AI integration. 
Currently focused on pushing the boundaries of HUD-inspired designs and AI-driven user experiences.
Based in the digital frontier, building the future of the web.
`;

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: "NEURAL NETWORK VISUALIZER",
    description: "An interactive real-time visualization tool for machine learning training cycles.",
    tags: ["React", "D3.js", "Tensorflow"],
    link: "#",
    status: "COMPLETED"
  },
  {
    id: 2,
    title: "QUANTUM TRADING HUD",
    description: "High-frequency crypto trading dashboard with low-latency data streams and holographic charts.",
    tags: ["WebSockets", "Three.js", "Tailwind"],
    link: "#",
    status: "IN_PROGRESS"
  },
  {
    id: 3,
    title: "AI AGENT COORDINATOR",
    description: "Multi-agent system orchestration platform with autonomous task management.",
    tags: ["Node.js", "OpenAI", "React"],
    link: "#",
    status: "COMPLETED"
  }
];

export const EXPERIENCE: ExperienceItem[] = [
  {
    id: 1,
    role: "Lead Interface Architect",
    company: "Stark Digital Systems",
    period: "2021 - PRESENT",
    details: [
      "Designed and implemented core HUD components for tactical displays.",
      "Optimized rendering pipelines for high-performance dashboards.",
      "Mentored a team of 10+ frontend engineers."
    ]
  },
  {
    id: 2,
    role: "Senior Software Engineer",
    company: "Cyberdyne Corp",
    period: "2018 - 2021",
    details: [
      "Led the transition from legacy monolith to React micro-frontends.",
      "Developed internal design systems used across 5 global departments.",
      "Reduced build times by 40% through custom CI/CD workflows."
    ]
  }
];

export const SKILLS: Skill[] = [
  { name: "React / Next.js", level: 95, category: "FRONTEND" },
  { name: "TypeScript", level: 90, category: "CORE" },
  { name: "Tailwind CSS", level: 98, category: "FRONTEND" },
  { name: "Node.js", level: 85, category: "BACKEND" },
  { name: "Gemini API", level: 88, category: "TOOLS" },
  { name: "Three.js / D3", level: 80, category: "FRONTEND" }
];
